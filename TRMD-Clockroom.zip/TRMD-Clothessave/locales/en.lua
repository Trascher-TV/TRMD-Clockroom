Locales['en'] = {
	['press_menu'] = 'Clockroom',
	['player_save'] = 'Clockroom'
}
 