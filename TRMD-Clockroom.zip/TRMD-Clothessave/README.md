# esx_clothessave 
This is Script is createt by TRMD leader Trascher_TV#0001

This is a Script for Wasabi’s fivem-appearance!

Plug in play more not.

Have Fun!